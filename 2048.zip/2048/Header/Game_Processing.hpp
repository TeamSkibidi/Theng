
void createSavegame(int** &saveGame, int n);
void Rand_game(int** &Matrix, int n);
void save_Game(int** Matrix, int n, int** &saveGame, int score, int &save_score);
void resGame(int** Matrix, int n);
bool check_full(int** Matrix, int n);
bool check_key(int** Matrix, int n, int** saveGame);

