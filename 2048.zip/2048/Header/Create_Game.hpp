

void SizeGame(int &n);
void Create_Game(int** &Matrix, int n);
bool end_Game(int** Matrix, int n);
    

