


void PrintGame(int** Matrix, int n, int** saveGame, int score, int Best_score);
void savePoint(std::ofstream &fout, std::string file, int Bestscore);
void Readfile(std::ifstream &fin, std::string file, int &Bestscore);
void Print_Menu(int Best_score, int score);