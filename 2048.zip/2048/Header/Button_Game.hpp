

void moveUp(int** &Matrix, int n, int &score); // moveup 
void moveLeft(int** &Matrix, int n, int &score);
void moveDown(int** &Matrix,int n, int &score);
void moveRight(int** &Matrix,int n, int &score);
void redo_Game(int** &Matrix, int n, int** saveRedo, int &score, int save_score);
void undo_Game(int** &Matrix, int n, int** saveUndo, int &score, int save_score);
 
