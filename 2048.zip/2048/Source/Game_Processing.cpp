#include "../Header/Game_Processing.hpp"
#include <ctime>


void createSavegame(int** &saveGame, int n) {
    saveGame = new int*[n];
    for (int i = 0; i < n; i++) {
        saveGame[i] = new int [n];
    }
}
void Rand_game(int** &Matrix, int n) {
    int j = rand() % n;
    int i = rand() % n;
    int u = rand() % n;
    int z = rand() % n;
    while (Matrix[i][j] != 0 || Matrix[u][z] != 0) {
        j = rand() % n;
        i = rand() % n;
        u = rand() % n;
        z = rand() % n;
        if (Matrix[i][j] == 0 && Matrix[u][z] == 0) {
            if (rand() % 2 == 0) {
                Matrix[i][j] = (rand() % 2 == 0) ? 2 : 4;
                return;
            }
            else {
                Matrix[i][j] = (rand() % 2 == 0) ? 2 : 2;
                Matrix[u][z] = (rand() % 2 == 0) ? 2 : 2;
                return;
            }
        }
    }
    if (Matrix[i][j] == 0 && Matrix[u][z] == 0) {
        if (rand() % 2 == 0) {
            Matrix[i][j] = (rand() % 2 == 0) ? 2 : 2;
        }
        else {
            Matrix[i][j] = (rand() % 2 == 0) ? 2 : 2;
            Matrix[u][z] = (rand() % 2 == 0) ? 2 : 2;
        }
    }
}
void save_Game(int** Matrix, int n, int** &saveGame, int score, int &save_score) {
    save_score = score;
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            saveGame[i][j] = Matrix[i][j];
        }
    }
}
void resGame(int** Matrix, int n) {
    for (int i = 0; i < n; i++) {
        delete[] Matrix[i];
    }
    delete[] Matrix;
}
bool check_full(int** Matrix, int n) {
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            if (Matrix[i][j] == 0) {
                return false;
            }
        }
    }
    return true; 
}
bool check_key(int** Matrix, int n, int** saveGame) {
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            if(Matrix[i][j] != saveGame[i][j]) {
                return false;
            }
        }
    }
    return true;
}

