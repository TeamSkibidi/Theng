#include "../Header/Create_Game.hpp"
#include <conio.h>

void SizeGame(int &n) {
    bool check_sizeGame = false;
    outtextxy (200, 200, const_cast<char*>("Enter to the size game"));
    while(check_sizeGame == false) {
        if(kbhit()){
            char command = getch();
            if (command >= '1' && command <= '9') {
                n = command - '0';  
            check_sizeGame = true;
            }
        }
    }
}
void Create_Game(int** &Matrix, int n) {
    Matrix = new int*[n];
    for (int i = 0; i < n; i++) {
        Matrix[i] = new int[n];
        for (int j = 0; j < n; j++) {
            Matrix[i][j] = 0;
        }
    }
}
bool end_Game(int** Matrix, int n) {
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            if( i < n - 1)
                if (Matrix[i][j] == Matrix[i + 1][j])
                    return false;
            if( j < n - 1){
                if (Matrix[i][j] == Matrix[i][j + 1])
                    return false;
            }
            if (Matrix[i][j] == 0) {
                return false;
            }
        }
    }
    return true;
}

 
