#include "../Header/Process_out.hpp"
#include "../Header/Create_Game.hpp"
#include <graphics.h>
#include <iostream>
#include <conio.h>
#include <string>
#include <fstream>


// Print board game
void PrintGame(int** Matrix, int n, int** saveGame, int score, int Best_score) {

    cleardevice();
    // Print out the menu
    Print_Menu(Best_score, score);
    // Print the rectangle cells to create a game board of size n * n
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            if (Matrix[i][j] != 0) {
                rectangle(120 + j * 60, 120 + i * 60, 170 + j * 60, 170 + i * 60);
                outtextxy(135 + j * 60, 135 + i * 60, const_cast<char*>(std::to_string(Matrix[i][j]).c_str()));
            }
            else {
                rectangle(120 + j * 60, 120 + i * 60, 170 + j * 60, 170 + i * 60);
            }

        }
    }
}
void Print_Menu(int Best_score, int score) {
    // Print menu of 
    outtextxy(10, 30, const_cast<char*>(("n : New game, q :  Quit game, u : Undo, r : Redo ")));
    outtextxy(10, 10, const_cast<char*>(("Use key: ")));
    outtextxy(10, 50, const_cast<char*>(("w :Move up, s : Move down, a : Move left, d : Move right,")));
    outtextxy(20, 90, const_cast<char*>(("Best score: " + std::to_string(Best_score)).c_str()));
    outtextxy(20, 70, const_cast<char*>(("Score: " + std::to_string(score)).c_str()));
}
void savePoint(std::ofstream &fout, std::string file, int Bestscore) {
    fout.open(file, std::ios::binary);

    if (!fout) {
        cleardevice();
        outtextxy(200, 200, const_cast<char*>("Erorr"));
        return;
    }

    fout.write((char*)&Bestscore, sizeof(Bestscore));

    fout.close();
}
void Readfile(std::ifstream &fin, std::string file, int &Bestscore) {
    fin.open(file, std::ios::binary);

    if(!fin) {
        cleardevice();
        outtextxy(150, 150, const_cast<char*>("Error"));
        return;
    }

    fin.read((char*)&Bestscore, sizeof(Bestscore));

    fin.close();
}