#include <graphics.h>
#include <conio.h>
#include <iostream>
#include <ctime>
#include <string>
#include <cstring>
#include "Button_Game.cpp"
#include "Create_Game.cpp"
#include "Game_Processing.cpp"
#include "Process_out.cpp"
#include <fstream>


int main() {

    int lineRows = DETECT, lineCols;
    initgraph(&lineRows, &lineCols, NULL);
    srand(static_cast<unsigned int> (time(NULL)));

    //Declare
    int n , score = 0, saveScore = 0, BestScore = 0, countRedo = 0;
    int** Matrix = NULL;
    int** saveUndo = NULL;
    int** saveRedo = NULL;
    char ButtonGame[128];

    ButtonGame['w'] = 0;
    ButtonGame['s'] = 1;
    ButtonGame['d'] = 2;
    ButtonGame['a'] = 3;
    ButtonGame['u'] = 4;
    ButtonGame['r'] = 5;
    ButtonGame['x'] = 6;

    std::ifstream fin;
    // Read data from a file binary
        Readfile(fin, "Player_info.bin", BestScore);

    // Create size game
        SizeGame(n);
        Create_Game(Matrix, n);

    // Save game 
        createSavegame(saveUndo, n);
        createSavegame(saveRedo, n);

    // Print size game
        PrintGame(Matrix, n, saveUndo, score, BestScore);
        cleardevice();

    // Print game guide
        outtextxy(200, 200, const_cast<char*>("PRESS N TO START A NEW GAME"));

    // Enable the game to run
    while(true) {

        // Set up the button for the game 
            if(kbhit()) {
            
                char command = getch();
                int current = ButtonGame[command];
                
                // Create a button for the new game
                if(command == 'n') {
                    
                    resGame(Matrix, n);
                    Create_Game(Matrix, n);
                    Rand_game(Matrix, n);
                    score = 0;
                }

                // Create a button to quit gamee
                else if(command == 'q') {
                    break;
                }

                // Create functional buttons for the game
                else  {

                    // Check if the movements are accrurate
                    std::cout << current << "\n";

                    // Button move up
                    if (current == 0) {
                        save_Game(Matrix, n, saveUndo, score, saveScore);
                        moveUp(Matrix, n, score);
                        if (countRedo == 1) {
                            resGame(saveRedo, n);
                            countRedo = 0;
                        }
                        
                    }

                    // Button move down
                    else if (current == 1) {
                        save_Game(Matrix, n, saveUndo, score, saveScore);
                        moveDown(Matrix, n, score);
                        if (countRedo == 1) {
                            resGame(saveRedo, n);
                            countRedo = 0;
                        }
                        
                    }

                    // Button move right
                    else if (current == 2) {
                        save_Game(Matrix, n, saveUndo, score, saveScore);
                        moveRight(Matrix, n, score);
                        if (countRedo == 1) {
                            resGame(saveRedo, n);
                            countRedo = 0;
                        }
                        
                    }

                    // Button move left
                    else if (current == 3) {
                        save_Game(Matrix, n, saveUndo, score, saveScore);
                        moveLeft(Matrix, n, score);
                        if (countRedo == 1) {
                            resGame(saveRedo, n);
                            countRedo = 0;
                        }
                        
                    }

                    // Button undo game
                    else if (current == 4 && countRedo == 0) {
                        save_Game(Matrix, n, saveRedo, score, saveScore);
                        undo_Game(Matrix, n, saveUndo, score, saveScore);
                        countRedo = 1;
                    }

                    // Button redo game
                    else if (current == 5 && countRedo == 1) {
                        save_Game(Matrix, n, saveUndo, score, saveScore);
                        redo_Game(Matrix, n, saveRedo, score, saveScore);
                        countRedo = 0;
                    }
                }

                // 
                if (score >= BestScore) {
                    BestScore = score;
                }

                //
                if(check_full(Matrix, n) == false && check_key(Matrix, n, saveUndo) == false && current != 4 && current != 5) {
                    Rand_game(Matrix, n);
                }
                PrintGame(Matrix, n, saveUndo, score, BestScore);
                if(end_Game(Matrix, n) == true) {
                    cleardevice();
                    PrintGame(Matrix, n, saveUndo, score, BestScore);
                    outtextxy(128, 400, const_cast<char*>("You lost, you can press 'u' or 'r' to restart the game"));
                }
            }
            delay(10);
    }
    std::ofstream fout;
    savePoint(fout, "Player_info.bin", BestScore);
    resGame(Matrix, n);
    resGame(saveUndo, n);
    resGame(saveRedo, n);
    closegraph();
    return 0;
}
